# DoxTracker 1.0
![](https://img.shields.io/badge/DoxTracker-Python-blue.svg)

![DoxTracker.jpg](https://github.com/KURO-CODE/DoxTracker/blob/master/DoxTracker.jpg)


# DISCLAMER: Program for educational purposes!!!

# INFO
Simple doxing tool

* Name: DoxTraker
* Version: 1.0 Beta
* Dev: Python
* Date: 03/12/2017
* By: KURO-CODE

# Download
```bash
git clone https://github.com/KURO-CODE/DoxTracker.git
```

# Usage
```bash
cd DoxTracker
python DoxTracker.py
```
